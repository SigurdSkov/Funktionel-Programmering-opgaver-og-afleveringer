﻿module Parser

open FParsec

type Duration = int

type DurationType =
     | Normal of Duration
     | Extended of Duration


type Pitch = 
    | Rest
    | Note of string  * int option

type Token = { Duration: DurationType
               Pitch: Pitch } 

let parseDuration = pint32 .>>. opt (pstring ".")

let parseNormPitch = many (anyOf "#abcdefg-")

let parseOctave  =  opt pint32 .>> opt eof

let TokenCreator duration pitch octave =
    let dur  = 
        match duration with
        | (x,None) -> Normal x
        | (x,_) -> Extended x

    let tmpPitch = pitch |> List.map (fun x -> string x) |> List.reduce (+)
    let tmpOctave = octave |> Option.map (fun x -> int x) 

    let pit =
        match (tmpPitch,tmpOctave) with
        | ("-",_) -> Rest
        | (x,Some(y)) -> Note(x,Some(y))
        | (x,None) -> Note(x,None)
    {
        Duration = dur
        Pitch = pit
    }

let parseToken = pipe3 parseDuration parseNormPitch parseOctave TokenCreator

let pScore: Parser<Token list, unit> = many (parseToken .>> spaces) 

let parse (input: string): Choice<string, Token list> =
    match run pScore input with
    | Failure(errorMsg,_,_)-> Choice1Of2(errorMsg)
    | Success(result,_,_) -> Choice2Of2(result)

// Helper function to test parsers
let test (p: Parser<'a, unit>) (str: string): unit =
    match run p str with
    | Success(result, _, _) ->  printfn "Success: %A" result
    | Failure(errorMsg, _, _) -> printfn "Failure: %s" errorMsg

// TODO 3 calculate duration from token.
// bpm = 120 (bpm = beats per minute)
// 'Duration in seconds' * 1000 * 'seconds per beat' (if extended *1.5)
// Whole note: 4 seconds
// Half note: 2 seconds
// Quarter note: 1 second
// Eight note: 1/2 second
// Sixteenth note 1/4 second
// thirty-second note: 1/8
let durationFromToken (token: Token): float = 
    let duration =
        match token.Duration with
        | Normal x -> 4.0 /(float x)
        | Extended x -> 4.0 * 1.5 / (float x)

    1000.0 * (duration) * 0.5
    
// TODO 4 calculate overall index of octave
// note index + (#octave-1) * 12
type OverAllIndex = Pitch -> int

let overallIndex : OverAllIndex = 
    fun pitch ->
        let note = 
            match pitch with
            | Note ("a",Some octave) -> (0,octave)
            | Note ("#a",Some octave) -> (1,octave)
            | Note ("b",Some octave) -> (2,octave)
            | Note ("c",Some octave) -> (3,octave)
            | Note ("#c",Some octave) -> (4,octave)
            | Note ("d",Some octave) -> (5,octave)
            | Note ("#d",Some octave) -> (6,octave)
            | Note ("e",Some octave) -> (7,octave)
            | Note ("f",Some octave) -> (8,octave)
            | Note ("#f",Some octave) -> (9,octave)
            | Note ("g",Some octave) -> (10,octave)
            | Note ("#g",Some octave) -> (11,octave)  
            | Rest _ -> failwith "This is NOT a note"
        fst note + ((snd note) - 1) * 12

// TODO 5 calculate semitones between to notes*octave
// [A; A#; B; C; C#; D; D#; E; F; F#; G; G#]
// overallIndex upper - overallIndex lower
let semitonesBetween lower upper = 
    match (lower,upper) with
    | Note(_) , Note(_) ->  overallIndex(upper) - overallIndex(lower)
    | Rest , _ -> 0
    | _ , Rest -> 0
   
// TODO 6
// For a tone frequency formula can be found here: http://www.phy.mtu.edu/~suits/NoteFreqCalcs.html
// 220 * 2^(1/12) ^ semitonesBetween (A1, Token.pitch) 
let frequency (token: Token): float =
    220.0 * (2.0**(1.0/12.0))**(float (semitonesBetween (Note ("a",Some(1))) token.Pitch  ) )