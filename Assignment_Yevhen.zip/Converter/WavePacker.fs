﻿module WavePacker

open System.IO
open System.Text
open System.Buffers.Binary;

// TODO 7 write data to stream
// http://soundfile.sapp.org/doc/WaveFormat/
// subchuncksize 16
// audioformat: 1s
// num channels: 1s
// sample rate: 44100
// byte rate: sample rate * number of channels *16/8
// block origin: 2s
// bits per sample: 16s
let pack (d: int16[]) =
    let stream = new MemoryStream()
    let writer = new BinaryWriter(stream, Encoding.ASCII)
    let dataLength = Array.length d
    
    let NumSamples = dataLength
    
    //fmt
    let Subchunk1ID: int32 = 0x666d7420
    let Subchunk1Size: int32 = 16
    let AudioFormat: int16 = int16 1
    let NumChannels: int16 = int16 1
    let SampleRate: int32 = 44100
    let BitsPerSample: int16 = int16 16
    let ByteRate: int32 = SampleRate * int32  NumChannels * int32 BitsPerSample/8
    let BlockAlign: int16 = NumChannels * BitsPerSample/int16 8
    
     // data
    let Subchunk2ID: int32 = 0x64617461
    let Subchunk2Size: int32 = NumSamples * int32 NumChannels * int32 BitsPerSample/8


    // RIFF
    let ChunkID: int32 = 0x52494646
    let ChunkSize: int32 = 4 + (8 + Subchunk1Size) + (8 + Subchunk2Size)
    let Format: int32 = 0x57415645
    
    writer.Write(BinaryPrimitives.ReverseEndianness(ChunkID))
    writer.Write(ChunkSize)
    writer.Write(BinaryPrimitives.ReverseEndianness(Format))
    writer.Write(BinaryPrimitives.ReverseEndianness(Subchunk1ID))
    writer.Write(Subchunk1Size)
    writer.Write(AudioFormat)
    writer.Write(NumChannels)
    writer.Write(SampleRate)
    writer.Write(ByteRate)
    writer.Write(BlockAlign)
    writer.Write(BitsPerSample)
    writer.Write(BinaryPrimitives.ReverseEndianness(Subchunk2ID))
    writer.Write(Subchunk2Size)
    d |> Array.toList |> List.iter (fun x -> writer.Write(x))
    
    stream
    
let write filename (ms: MemoryStream) =
    use fs = new FileStream(Path.Combine(__SOURCE_DIRECTORY__, filename), FileMode.Create) // use IDisposible
    ms.WriteTo(fs)
