﻿
open System
open Parser
open WavePacker

// TODO 8 take input from file/cmd and save it to a file
[<EntryPoint>]
let main argv =
    printfn "Now input multiple valid nokia tones: "
    let score = System.Console.ReadLine()
    let result = parse score
    printfn "%A" result
    match Assembler.assembleToPackedStream score with
            | Choice2Of2 ms ->
                write "NokiaSondFile.wav" ms
            | Choice1Of2 err -> failwith err

    0