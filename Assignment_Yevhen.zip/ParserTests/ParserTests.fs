module ParserTests

open NUnit.Framework
open Parser

[<SetUp>]
let Setup () =
    ()
open NUnit.Framework

[<TestFixture>]
type tests() =
    
    [<Test>]
    member __.``durationFromToken returns expected duration``() =
        let token = { Duration = Normal 4; Pitch = Note("a", Some(1))}
        let duration = durationFromToken token
        Assert.AreEqual(500.0, duration)
        
    [<Test>]
    member __.``overallIndex returns expected index``() =
        let pitch = Note("a", Some(2))
        let index = overallIndex pitch
        Assert.AreEqual(12, index)
        
    [<Test>]
    member __.``semitonesBetween returns expected semitones``() =
        let lower = Note("a", Some(1))
        let upper = Note("c", Some(2))
        let semitones = semitonesBetween lower upper
        Assert.AreEqual(15, semitones)
        
    [<Test>]
    member __.``frequency returns expected frequency``() =
        let token = { Duration = Normal 4; Pitch = Note("c", Some(2))}
        let freq = frequency token
        Assert.AreEqual(523.25, freq, 0.1)

    [<Test>]
    member __. ``It should parse a simple score`` () =
        let score = "32.#d3 16-"
        let result = parse score

        let assertFirstToken token =
            match token.Duration with
            | Extended duration ->
                Assert.AreEqual(32, duration)
            | Normal _ -> 
                Assert.Fail("Expected extended duration got a Normal")
            match token.Pitch with
            | Note (note, octave) ->
                Assert.AreEqual("#d", note)
                Assert.AreEqual(Some 3, octave)
            | _ ->
                Assert.Fail("Expected a note, but got a rest")

        let assertSecondToken token =
            match token.Duration with
            | Normal duration ->
                Assert.AreEqual(16, duration)
            | _ ->
                Assert.Fail("Expected a normal duration, but got an extended duration")
            match token.Pitch with
            | Rest ->
                Assert.Pass()
            | _ ->
                Assert.Fail("Expected a rest, but got a note")
         
        match result with
            | Choice1Of2 errorMsg -> Assert.Fail(errorMsg)
            | Choice2Of2 tokens ->
                Assert.AreEqual(2, List.length tokens)
                List.head tokens |> assertFirstToken
                List.item 1 tokens |> assertSecondToken
    [<Test>]
    member __. ``Another Test Case`` ()= 
        let input = "1d2 4d2 4e2 2.#f2 1g2 4#a5 1- 1#b"
        let expected = [
            { Duration = Normal 1; Pitch = Note ("d", Some 2) }
            { Duration = Normal 4; Pitch = Note ("d", Some 2) }
            { Duration = Normal 4; Pitch = Note ("e", Some 2) }
            { Duration = Extended 2; Pitch = Note ("#f", Some 2) }
            { Duration = Normal 1; Pitch = Note ("g", Some 2) }
            { Duration = Normal 4; Pitch = Note ("#a", Some 5) }
            { Duration = Normal 1; Pitch = Rest }
            { Duration = Normal 1; Pitch = Note ("#b", None) }
        ]

        let actual = match parse input with
                     | Choice1Of2 errMsg -> failwith errMsg
                     | Choice2Of2 result -> result

        Assert.AreEqual(expected, actual)